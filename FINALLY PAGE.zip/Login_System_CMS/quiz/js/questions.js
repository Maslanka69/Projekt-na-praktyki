
var questions = [
  {
    numb: 1,
    question: "Co oznacza skrót HTML?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 2,
    question: "System plików, który nie wspiera tworzenia wewnętrznego dziennika zmian, zwanego księgowaniem to",
    answer: "FAT32",
    options: [
      "ext4",
      "ext3",
      "FAT32",
      "NTFS"
    ]
  },
  {
    numb: 3,
    question: "Programem antywirusowym nie jest",
    answer: "PacketFilter",
    options: [
      "PacketFilter",
      "AVG",
      "NOD32",
      "AVAST"
    ]
  },
  {
    numb: 4,
    question: "Która licencja ma charakter grupowy oraz umożliwia instytucjom komercyjnym lub organizacjom edukacyjnym, państwowym, charytatywnym zakup na korzystnych warunkach większej liczby oprogramowania firmy Microsoft?",
    answer: "MOLP",
    options: [
      "MOLP",
      "OEM",
      "MPL",
      "APSL"
    ]
  },
  {
    numb: 5,
    question: "Jednostką opisującą szybkość transmisji danych w sieciach komputerowych jest",
    answer: "bps",
    options: [
      "ips",
      "dpi",
      "mips",
      "bps"
    ]
  },
  {
    numb: 6,
    question: "Do zabezpieczenia systemów sieciowych przed atakami z zewnątrz należy użyć",
    answer: "zapory sieciowej",
    options: [
      "protokołu SSH",
      "zapory sieciowej",
      "menadżera połączeń",
      "serwera DHCP"
    ]
  },
  {
    numb: 7,
    question: " Który ze standardów Gigabit Ethernet umożliwia budowę segmentów sieci o długości 550 m/5000 m z prędkością transmisji 1 Gb/s?",
    answer: "1000Base-LX",
    options: [
      "1000Base-T",
      "1000Base-FX",
      "1000Base-LX",
      "1000Base-SX"
    ]
  },
  {
    numb: 8,
    question: "Który typ kabla należy zastosować do podłączenia komputera w pomieszczeniu z zakłóceniami elektromagnetycznymi?",
    answer: "FTP Cat 5e",
    options: [
      "UTP Cat 5",
      "FTP Cat 5e",
      "UTP Cat 5e",
      "UTP Cat 6"
    ]
  },
  {
    numb: 9,
    question: " Adresy IPv6 są liczbami",
    answer: "28 bitowymi wyrażanymi w postaci napisów szesnastkowych",
    options: [
      "256 bitowymi wyrażanymi w postaci napisów szesnastkowych",
      "32 bitowymi wyrażanymi w postaci napisów binarnych",
      "64 bitowymi wyrażanymi w postaci napisów binarnych",
      "28 bitowymi wyrażanymi w postaci napisów szesnastkowych"
    ]
  },
  {
    numb: 10,
    question: "Którego z poleceń systemu Linux należy użyć do utworzenia archiwum danych?",
    answer: "tar",
    options: [
      "date",
      "grep",
      "cal",
      "tar"
    ]
  },
  {
    numb: 11,
    question: "W systemie Linux polecenie cd ~ służy do",
    answer: "przejścia do katalogu domowego użytkownika",
    options: [
      "przejścia do katalogu domowego użytkownika",
      "przejścia do katalogu głównego",
      "utworzenia katalogu /~",
      "wyszukania znaku ~ w zapisanych danych"
    ]
  },
  {
    numb: 12,
    question: "Główny księgowy musi mieć możliwość odzyskiwania zawartości folderów z kopii zapasowej plików. Do jakiej grupy użytkowników systemu MS Windows XP należy go przydzielić?",
    answer: "Operatorzy kopii zapasowych",
    options: [
      "Operatorzy kopii zapasowych",
      "Użytkownicy pulpitu zdalnego",
      "Użytkownicy z ograniczeniami",
      "Operatorzy konfiguracji sieci"
    ]
  },
  {
    numb: 13,
    question: "Aby serwer Windows mógł zarządzać usługami katalogowymi, należy zainstalować",
    answer: "kontroler domeny",
    options: [
      "kontroler domeny",
      "rolę serwera Web",
      "usługi zarządzania prawami",
      "rolę serwera DHCP"
    ]
  },
  {
    numb: 14,
    question: "Który element stanowi zawartość dokumentacji powykonawczej?",
    answer: "Wyniki testów sieci",
    options: [
      "Analiza biznesowa potrzeb zamawiającego",
      "Wyniki testów sieci",
      "Kalkulacja kosztów na podstawie katalogu nakładów rzeczowych KNR",
      "Wstępny kosztorys ofertowy"
    ]
  },

  {
    numb: 15,
    question: "W przedsiębiorstwie należy cyklicznie tworzyć kopie bezpieczeństwa dużej ilości danych, znajdujących się na serwerze, rzędu kilkuset GB. Jakie urządzenie najlepiej wykorzystać do tego celu?",
    answer: "Streamer",
    options: [
      "Streamer",
      "Nagrywarkę DVD",
      "Macierz RAID1",
      "Nagrywarkę CD"
    ]
  },
  {
    numb: 16,
    question: "Które z zaleceń jest NIEodpowiednie dla konserwacji skanera płaskiego?",
    answer: "Używać do czyszczenia szyby acetonu lub alkoholu etylowego wylewając bezpośrednio na szybę.",
    options: [
      "Używać do czyszczenia szyby acetonu lub alkoholu etylowego wylewając bezpośrednio na szybę.",
      "Uważać, aby podczas prac nie zarysować szklanej powierzchni tacy dokumentów.",
      "Uważać, aby podczas prac nie rozlać płynu na mechanizm skanera oraz na elementy elektroniczne.",
      "Sprawdzać, czy na powierzchni tacy dokumentów zebrał się kurz."
    ]
  },
  {
    numb: 17,
    question: "Usługa Windows XP Professional Mostek sieciowy pozwala na łączenie ze sobą",
    answer: "segmentów sieci LAN",
    options: [
      "klienta z serwerem",
      "dwóch komputerów",
      "roboczych stacji bezdyskowych",
      "segmentów sieci LAN"
    ]
  },
  {
    numb: 18,
    question: "W systemie Windows wymagania co do złożoności hasła należy określić w",
    answer: "zasadach zabezpieczeń lokalnych",
    options: [
      "autostarcie",
      "BIOS-ie",
      "zasadach zabezpieczeń lokalnych",
      "panelu sterowania"
    ]
  },
  {
    numb: 19,
    question: " Który standard realizacji sieci Ethernet, definiuje sieć zbudowaną na kablu koncentrycznym, odługości segmentu nie przekraczającym 185 m?",
    answer: "10Base-2",
    options: [
      "10Base-2",
      "100Base-T4",
      "10Base-5",
      "100Base-T2"
    ]
  },
  {
    numb: 20,
    question: "Dodatkowa funkcja mikroprocesora Intel Turbo Boost pozwala na",
    answer: "automatyczną regulację częstotliwości pracy mikroprocesora w zależności od obciążenia",
    options: [
      "wykonywanie większej liczby instrukcji w jednym cyklu zegara",
      "dokonywanie rozległych obliczeń przez dwa niezależne rdzenie, przy czym każdy z nich wykonuje do czterech pełnych instrukcji jednocześnie",
      "włączenie i wyłączenie elementów mikroprocesora w celu oszczędzania energii",
      "automatyczną regulację częstotliwości pracy mikroprocesora w zależności od obciążenia"
    ]
  },
  {
    numb: 21,
    question: "Ile bitów minimum będzie wymaganych w systemie binarnym do zapisania liczby heksadecymalnej 110 (h)?",
    answer: "9 bitów",
    options: [
      "16 bitów",
      "3 bity",
      "9 bitów",
      "4 bity"
    ]
  },
  {
    numb: 22,
    question: "Administrator systemu Linux wylistował zawartość katalogu /home/szkola w terminalu i uzyskał następujący wynik -rwx -x r-x 1 admin admin 25 04-09 15:17 szkola.txt Następnie wydał polecenie: chmod ug=rw szkola.txt | Is -I Jaki będzie efekt jego działania, wyświetlony w oknie terminala?",
    answer: "-rw- rw- r-x 1 admin admin 25 04-09 15:17 szkola.txt",
    options: [
      "-rw- rw- r-x 1 admin admin 25 04-09 15:17 szkola.txt",
      "-rw- rw- rw- 1 admin admin 25 04-09 15:17 szkola.txt",
      "-rwx r-x r-x 1 admin admin 25 04-09 15:17 szkola.txt",
      "-rwx ~x rw- 1 admin admin 25 04-09 15:17 szkola.txt"
    ]
  },
  {
    numb: 23,
    question: " Do której grupy w systemie Windows Server 2008 należy przydzielić użytkownika odpowiedzialnego tylko za archiwizowanie danych przechowywanych na dysku serwera?",
    answer: "Operatorzy kopii zapasowych",
    options: [
      "Użytkownicy pulpitu zdalnego",
      "Operatorzy kopii zapasowych",
      "Użytkownicy zaawansowani",
      "Użytkownicy domeny"
    ]
  },
  {
    numb: 24,
    question: "Program, który umożliwia komunikację między kartą sieciową a systemem operacyjnym, to",
    answer: "sterownik",
    options: [
      "sniffer",
      "middleware",
      "sterownik",
      "komunikator"
    ]
  },
  {
    numb: 25,
    question: "Urządzenie sieciowe most (ang. bridge):",
    answer: "jest urządzeniem typu store and forward",
    options: [
      "pracuje w zerowej warstwie modelu OSI",
      "nie analizuje ramki pod kątem adresu MAC",
      "jest urządzeniem typu store and forward",
      "pracuje w ósmej warstwie modelu OSI"
    ]
  },
  {
    numb: 26,
    question: " Która drukarka wykorzystuje technikę polegającą na przenoszeniu stałego barwnika z taśmy na papier odporny na wysoką temperaturę?",
    answer: "Termosublimacyjna",
    options: [
      "Atramentowa",
      "Laserowa",
      "Termiczna",
      "Termosublimacyjna"
    ]
  },
  {
    numb: 27,
    question: "Jaka drukarka powinna być zastosowana w dziale sprzedaży hurtowni materiałów budowlanych do drukowania faktur na papierze samokopiującym, tak aby uzyskać na nim kopie wydruku?",
    answer: "Igłowa",
    options: [
      "Igłowa",
      "Atramentowa",
      "Laserowa",
      "Sublimacyjna"
    ]
  },
  {
    numb: 28,
    question: "Aby zagwarantować użytkownikom Active Directory możliwość logowania się i dostęp do zasobów tej usługi w przypadku awarii kontrolera domeny, należy",
    answer: "zainstalować drugi kontroler domeny",
    options: [
      "dodać wszystkich użytkowników do grupy administratorzy",
      "zainstalować drugi kontroler domeny",
      "przekopiować wszystkie zasoby sieci na każdy komputer w domenie",
      "udostępnić wszystkim użytkownikom numer do Help Desk"
    ]
  },
  {
    numb: 29,
    question: "W adresie IP należącym do klasy A, wartość pierwszego bajtu jest zawarta w przedziale",
    answer: "0 - 127",
    options: [
      "0 - 127",
      "224 - 240",
      "192 - 223",
      "128 - 191"
    ]
  },
  {
    numb: 30,
    question: "Narzędzia dostrajania oraz Unity Tweak Tool to narzędzia systemu Linux służące do",
    answer: "personalizacji systemu",
    options: [
      "konfiguracji zapory systemowej",
      "personalizacji systemu",
      "zarządzania kontami użytkownika",
      "nadawania uprawnień do zasobów systemowych"
    ]
  },
  {
    numb: 31,
    question: "Mysz komputerowa z interfejsem bluetooth działającym w klasie 2 ma teoretyczny zasięg działania do",
    answer: "10 m",
    options: [
      "10 m",
      "2 m",
      "100 m",
      "1 m"
    ]
  },
  {
    numb: 32,
    question: "Wewnętrzny dysk twardy IDE zasilany jest poprzez złącze typu",
    answer: "Molex",
    options: [
      "SATA",
      "PCIe",
      "Molex",
      "ATX"
    ]
  },

  {
    numb: 33,
    question: "Aby odzyskać dane ze sformatowanego dysku twardego, należy wykorzystać program",
    answer: "RECUVA",
    options: [
      "RECUVA",
      "CDTrack Rescue",
      "Acronis True Image",
      "CD Recovery Toolbox Free"
    ]
  },
  {
    numb: 34,
    question: "Aby w budowanej sieci komputerowej zapewnić najmniejszy wpływ zakłóceń elektromagnetycznych na przesyłany sygnał należy zastosować",
    answer: "światłowód",
    options: [
      "światłowód",
      "ekranowaną skrętkę",
      "cienki przewód koncentryczny",
      "gruby przewód koncentryczny"
    ]
  },{
    numb: 35,
    question: "W sieci lokalnej protokołem dynamicznej konfiguracji adresów IP jest",
    answer: "DHCP",
    options: [
      "TCP/IP",
      "DNS",
      "DHCP",
      "FTP"
    ]
  },

  {
    numb: 36,
    question: "Funkcją serwera FTP jest",
    answer: "udostępnianie plików",
    options: [
      "synchronizacja czasu",
      "monitoring sieci",
      "synchronizacja czasu",
      "udostępnianie plików"
    ]
  },{
    numb: 37,
    question: "Tester okablowania strukturalnego pozwala sprawdzić",
    answer: "mapę połączeń",
    options: [
      "liczbę przełączników w sieci",
      "obciążenie ruchu sieciowego",
      "mapę połączeń",
      "liczbę komputerów w sieci"
    ]
  },
  {
    numb: 38,
    question: "Które polecenie należy zastosować do monitorowania lokalnych połączeń?",
    answer: "netstat",
    options: [
      "dir",
      "netstat",
      "host",
      "route add"
    ]
  },
  {
    numb: 39,
    question: "Technika transmisji danych pomiędzy urządzeniami CD/DVD a pamięcią komputera w trybie bezpośredniego dostępu do pamięci to",
    answer: "DMA",
    options: [
      "IDE",
      "PIO",
      "DMA",
      "SATA"
    ]
  },

  {
    numb: 40,
    question: "Powodem niekontrolowanego zapełnienia dysku może być",
    answer: "wirus komputerowy",
    options: [
      "źle skonfigurowana pamięć wirtualna",
      "częsta defragmentacja",
      "zbyt małe jednostki alokacji plików",
      "wirus komputerowy"
    ]
  },{
    numb: 41,
    question: "Gorące podłączenie (hot-plug) oznacza, że podłączane urządzenie jest",
    answer: "sprawne zaraz po podłączeniu, bez konieczności wyłączania bądź restartowania systemu",
    options: [
      "sprawne po zainstalowaniu właściwych sterowników",
      "sprawne zaraz po podłączeniu, bez konieczności wyłączania bądź restartowania systemu",
      "kompatybilne z komputerem",
      "sterowane temperaturą"
    ]
  },
  {
    numb: 42,
    question: "Jaka jest standardowa wartość maksymalnej odległości pomiędzy urządzeniami sieciowymi, połączonymi bezpośrednio przewodem UTP kat.5e?",
    answer: "100 m",
    options: [
      "500 m",
      "10 m",
      "1000 m",
      "100 m"
    ]
  },
  {
    numb: 43,
    question: "System S.M.A.R.T przeznaczony jest do monitorowania pracy i wykrywania błędów",
    answer: "dysków twardych",
    options: [
      "kart rozszerzeń",
      "dysków twardych",
      "napędów płyt CD/DVD",
      "płyty głównej"
    ]
  },

  {
    numb: 44,
    question: "Który z portów panelu tylnego płyty głównej jest oznaczany w dokumentacji jako port standardu RS232C?",
    answer: "COM",
    options: [
      "PS/2",
      "COM",
      "LPT",
      "USB"
    ]
  },{
    numb: 45,
    question: "Liczba FAFC zapisana w systemie heksadecymalnym odpowiada liczbie",
    answer: "1111101011111100 (2)",
    options: [
      "175376 (8)",
      "1111101011011101 (2)",
      "64256(10)",
      "1111101011111100 (2)"
    ]
  },
  {
    numb: 46,
    question: ". Aby sprawdzić adres fizyczny karty sieciowej, w wierszu poleceń systemu operacyjnego Microsoft Windows należy wpisać polecenie",
    answer: "ipconfig /all",
    options: [
      "get mac",
      "ifconfig -a",
      "ipconfig /all",
      "show mac"
    ]
  },
  {
    numb: 47,
    question: "Której funkcji należy użyć do wykonania kopii zapasowej rejestru systemowego w edytorze regedit?",
    answer: "Eksportuj",
    options: [
      "Załaduj gałąź rejestru",
      "Eksportuj",
      "Kopiuj nazwę klucza",
      "Importuj"
    ]
  },

  {
    numb: 48,
    question: "Jaki pierwszy znak w nazwie pliku w systemie Windows oznacza plik tymczasowy?",
    answer: "~",
    options: [
      "&",
      "#",
      "~",
      "*"
    ]
  },
  {
    numb: 49,
    question: "Adresy IPv6 są liczbami",
    answer: "128 bitowymi wyrażanymi w postaci napisów szesnastkowych",
    options: [
      "64 bitowymi wyrażanymi w postaci napisów binarnych",
      "32 bitowymi wyrażanymi w postaci napisów binarnych",
      "128 bitowymi wyrażanymi w postaci napisów szesnastkowych",
      "256 bitowymi wyrażanymi w postaci napisów szesnastkowych"
    ]
  },
  {
    numb: 50,
    question: "Ile jest adresów IP dostępnych do adresowania komputerów w sieci o adresie 192.168.100.0 i masce 255.255.255.0?",
    answer: "254",
    options: [
      "254",
      "255",
      "256",
      "253"
    ]
  },

];




// Funkcja shuffle() do losowego przemieszania elementów tablicy
function shuffle(array) {
  let currentIndex = array.length, temporaryValue, randomIndex;
  
  while (0 !== currentIndex) {
    // Wylosowanie indeksu do zamiany
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    
    // Zamiana elementów
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  
  return array;
}

// Przemieszanie elementów tablicy questions
questions = shuffle(questions);

// Wyświetlenie losowo przemieszanych pytań w konsoli
console.log(questions);
;