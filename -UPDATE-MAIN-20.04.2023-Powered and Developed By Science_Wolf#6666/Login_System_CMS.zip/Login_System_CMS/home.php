<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Home Page</title>
		<link href="style1.css" rel="stylesheet" type="text/css">
		<link href="style2.css" rel="stylesheet" type="text/css">
		<link href="style3.css" rel="stylesheet" type="text/css">
		<link href="style4.css" rel="stylesheet" type="text/css">
		<link href="style5.css" rel="stylesheet" type="text/css">
		<link href="baton.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin" style="overflow: scroll;">
		<nav class="navtop">
			<div>
				<h1>Strona dla Marynarki Wojennej w Gdyni</h1>
				<a href="home.php"><i class="fas fa-sign-out-alt"></i>Back to Home</a>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>

		<div class="content">
			<h2>Home Page 1</h2>
			<br>
			<br>
			<a class="button" href="home2.php"><span>Kalkulator IP</span></a>
		</div>

		</div>
	</body>
</html>
