
let questions = [
  {
    numb: 1,
    question: "Co oznacza skrót HTML?",
    answer: "Hyper Text Markup Language",
    options: [
      "Hyper Text Preprocessor",
      "Hyper Text Markup Language",
      "Hyper Text Multiple Language",
      "Hyper Tool Multi Language"
    ]
  },
  {
    numb: 1,
    question: "System plików, który nie wspiera tworzenia wewnętrznego dziennika zmian, zwanego księgowaniem to",
    answer: "FAT32",
    options: [
      "ext4",
      "ext3",
      "FAT32",
      "NTFS"
    ]
  },
  {
    numb: 1,
    question: "Programem antywirusowym nie jest",
    answer: "PacketFilter",
    options: [
      "PacketFilter",
      "AVG",
      "NOD32",
      "AVAST"
    ]
  },
  {
    numb: 1,
    question: "Tester okablowania strukturalnego pozwala sprawdzić",
    answer: "mapę połączeń",
    options: [
      "liczbę przełączników w sieci",
      "obciążenie ruchu sieciowego",
      "mapę połączeń",
      "liczbę komputerów w sieci"
    ]
  },
  {
    numb: 1,
    question: "Jednostką opisującą szybkość transmisji danych w sieciach komputerowych jest",
    answer: "bps",
    options: [
      "ips",
      "dpi",
      "mips",
      "bps"
    ]
  }
];

// Funkcja shuffle() do losowego przemieszania elementów tablicy
function shuffle(array) {
  let currentIndex = array.length, temporaryValue, randomIndex;
  
  while (0 !== currentIndex) {
    // Wylosowanie indeksu do zamiany
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    
    // Zamiana elementów
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }
  
  return array;
}

// Przemieszanie elementów tablicy questions
questions = shuffle(questions);

// Wyświetlenie losowo przemieszanych pytań w konsoli
console.log(questions);
;