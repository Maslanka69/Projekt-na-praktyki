const quizData = [
    {
        question: "1.Co oznacza skrót HTML?",
        a: "Hyper Text Markup Language",
        b: "Hyperlinking Text Making Language",
        c: "Hyper Terminal Mainframe Language",
        d: "Hacking Terminal Mainframe Language",
        correct: "a",
    },
    {
        question: "2.System plików, który nie wspiera tworzenia wewnętrznego dziennika zmian, zwanego księgowaniem to",
        a: "ext4",
        b: "ext3",
        c: "FAT32",
        d: "NTFS",
        correct: "c",
    },
    {
        question: "3.Programem antywirusowym nie jest",
        a: "PacketFilter",
        b: "AVG",
        c: "NOD32",
        d: "AVAST",
        correct: "a",
    },
    {
        question: "4.Tester okablowania strukturalnego pozwala sprawdzić",
        a: "liczbę przełączników w sieci",
        b: "obciążenie ruchu sieciowego",
        c: "mapę połączeń",
        d: "liczbę komputerów w sieci",
        correct: "c",
    },

    {
        question: "5.Jednostką opisującą szybkość transmisji danych w sieciach komputerowych jest",
        a: "ips",
        b: "mips",
        c: "bps",
        d: "dpi",
        correct: "c",
    },

    {
        question: "6.Zestaw reguł definiujących sposób przesyłania informacji w sieci opisuje",
        a: "zasada",
        b: "protokół",
        c: "reguła",
        d: "standard",
        correct: "b",
    },

    {
        question: "7.Metoda dostępu do medium CSMA/CA jest stosowana w sieci o standardzie",
        a: "IEEE 802.3",
        b: "IEEE 802.11",
        c: "IEEE 802.8",
        d: "IEEE 802.1",
        correct: "b",
    },

    {
        question: "8.Adres IP (ang. Internet Protocol Address) jest",
        a: "unikatowym numerem fabrycznym urządzenia",
        b: "adresem fizycznym komputera",
        c: "unikatową nazwą symboliczną urządzenia",
        d: "adresem logicznym komputera",
        correct: "d",
    },

    {
        question: "9.Które urządzenie NIE powinno być naprawiane w trakcie używania urządzeń antystatycznych?",
        a: "Modem",
        b: "Zasilacz",
        c: "Pamięć",
        d: "Dysk twardy",
        correct: "b",
    },
    
    {
        question: "10.Ile warstw definiuje model ISO/OSI",
        a: "9",
        b: "3",
        c: "7",
        d: "5",
        correct: "c",
    },

];

const quiz= document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('Dalej')


let currentQuiz = 0
let score = 0

loadQuiz()

function loadQuiz() {

    deselectAnswers()

    const currentQuizData = quizData[currentQuiz]

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

function getSelected() {
    let answer
    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })
    return answer
}


submitBtn.addEventListener('click', () => {
    const answer = getSelected()
    if(answer) {
       if(answer === quizData[currentQuiz].correct) {
           score++
       }

       currentQuiz++

       if(currentQuiz < quizData.length) {
           loadQuiz()
       } else {
           quiz.innerHTML = `
           <h2>Odpowiedziałes poprawnie na ${score}/${quizData.length} pytań</h2>

           <button onclick="location.reload()">Zacznij od nowa</button>
           `
       }
    }
})