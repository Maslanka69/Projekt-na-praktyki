<?php
function calculate_network($ip_address, $subnet_mask)
{
    // konwersja adresu IP i maski na liczby całkowite
    $ip_address = ip2long($ip_address);
    $subnet_mask = ip2long($subnet_mask);

    // obliczenie adresu sieci i adresu rozgłoszeniowego
    $network_address = $ip_address & $subnet_mask;
    $broadcast_address = $network_address | (~$subnet_mask & 0xffffffff);

    // obliczenie liczby hostów w sieci
    $num_hosts = ($broadcast_address - $network_address - 1);

    // obliczenie adresu pierwszego i ostatniego hosta
    $first_host_address = $network_address + 1;
    $last_host_address = $broadcast_address - 1;

    // konwersja wszystkich wartości na system dziesiętny
    $network_address = long2ip($network_address);
    $broadcast_address = long2ip($broadcast_address);
    $first_host_address = long2ip($first_host_address);
    $last_host_address = long2ip($last_host_address);

    // zwrócenie wyników jako tablicy asocjacyjnej
    return array(
        "network_address" => $network_address,
        "broadcast_address" => $broadcast_address,
        "num_hosts" => $num_hosts,
        "first_host_address" => $first_host_address,
        "last_host_address" => $last_host_address
    );
}

// domyślne wartości dla pól formularza
$ip_address = "";
$subnet_mask = "";

// jeśli formularz został przesłany, pobierz wartości z pól
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $ip_address = $_POST["ip_address"];
    $subnet_mask = $_POST["subnet_mask"];

    // obliczenie wyników
    $results = calculate_network($ip_address, $subnet_mask);
    $network_address = $results["network_address"];
    $broadcast_address = $results["broadcast_address"];
    $num_hosts = $results["num_hosts"];
    $first_host_address = $results["first_host_address"];
    $last_host_address = $results["last_host_address"];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kalkulator IP</title>
    <link href="style6.css" rel="stylesheet" type="text/css">
</head>
<body>
    <h1>Kalkulator IP</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="ip_address">Adres IP:</label>
        <input type="text" name="ip_address" id="ip_address" placeholder="np. 192.168.0.1" pattern="^(?!0)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$" required value="<?php echo $ip_address; ?>"><
        <br><br>
        <label for="subnet_mask">Maska podsieci:</label>
        <input type="text" name="subnet_mask" id="subnet_mask" placeholder="np. 255.255.255.0" pattern="^(?!0)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$" required value="<?php echo $subnet_mask; ?>">
        <br><br>
        <input type="submit" value="Oblicz">
        <a class="back-button" href="/Login_System_CMS/home.php">Return</a>
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (filter_var($ip_address, FILTER_VALIDATE_IP) && filter_var($subnet_mask, FILTER_VALIDATE_IP)) {
            echo "<h2>Wyniki:</h2>";
            echo "<ul>";
            echo "<li>Adres sieci: " . $network_address . "</li>";
            echo "<li>Adres rozgłoszeniowy: " . $broadcast_address . "</li>";
            echo "<li>Liczba hostów w sieci: " . $num_hosts . "</li>";
            echo "<li>Adres pierwszego hosta: " . $first_host_address . "</li>";
            echo "<li>Adres ostatniego hosta: " . $last_host_address . "</li>";
            echo "</ul>";
        } else {
            echo "<p>Podano nieprawidłowy adres IP lub maskę podsieci.</p>";
        }
    }
    ?>
</body>
</html>


